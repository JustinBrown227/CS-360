package com.example.weighttracker_justinbrown;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Make sure to set the correct layout

        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        Button loginButton = findViewById(R.id.login_button);
        Button registerButton = findViewById(R.id.create_account_button);

        userDatabase = new UserDatabase(this);

        loginButton.setOnClickListener(v -> loginUser());
        registerButton.setOnClickListener(v -> registerUser());
    }

    private void loginUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (userDatabase.checkUser(username, password)) {
            // Get user ID
            int userId = userDatabase.getUserId(username); // Add a method to get user ID based on username

            // Login successful
            Intent intent = new Intent(MainActivity.this, WeightDisplay.class);
            intent.putExtra("username", username);
            intent.putExtra("userId", userId);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Login failed. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        if (userDatabase.usernameExists(username)) {
            Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
        } else {
            if (userDatabase.addUser(username, password)) {
                Toast.makeText(this, "Registration successful.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Registration failed.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

