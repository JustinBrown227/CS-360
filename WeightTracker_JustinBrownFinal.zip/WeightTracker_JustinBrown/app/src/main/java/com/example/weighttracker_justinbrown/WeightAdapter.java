package com.example.weighttracker_justinbrown;

// WeightAdapter.Java
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {
    private final List<WeightEntry> weightEntries; // List of weight entries
    private final Context context;

    public WeightAdapter(List<WeightEntry> weightEntries, Context context) {
        this.weightEntries = weightEntries;
        this.context = context;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.weight_item, parent, false); // Inflate item layout
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.weightTextView.setText(String.valueOf(entry.getWeight())); // Set weight text
        holder.timestampTextView.setText(entry.getTimestamp()); // Set timestamp text
    }

    @Override
    public int getItemCount() {
        return weightEntries.size(); // Return the number of weight entries
    }

    // ViewHolder class to hold item views
    static class WeightViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView; // TextView for weight
        TextView timestampTextView; // TextView for timestamp

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weight_text);
            timestampTextView = itemView.findViewById(R.id.timestamp_text);
        }
    }
}
