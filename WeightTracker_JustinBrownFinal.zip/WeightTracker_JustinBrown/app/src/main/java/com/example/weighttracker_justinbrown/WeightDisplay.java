package com.example.weighttracker_justinbrown;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class WeightDisplay extends AppCompatActivity {
    private EditText weightEditText;  // Declare EditText for weight input
    private UserDatabase userDatabase; // Database instance
    private RecyclerView recyclerView; // RecyclerView for displaying weights
    private WeightAdapter adapter; // Adapter for the RecyclerView
    private List<WeightEntry> weightEntries; // List of weight entries
    private String goalWeightText = "Goal Weight: n/a"; // Default goal weight text
    private float goalWeight; // Variable to store goal weight

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display); // Set the layout for this activity

        String username = getIntent().getStringExtra("username");
        userDatabase = new UserDatabase(this);
        weightEntries = new ArrayList<>(); // Initialize the weight entries list

        // Initialize UI components
        weightEditText = findViewById(R.id.weight_edit_text);
        Button addGoalButton = findViewById(R.id.add_goal_button);
        Button logWeightButton = findViewById(R.id.log_weight_button);
        Button editRowsButton = findViewById(R.id.edit_row_button);
        recyclerView = findViewById(R.id.data_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Set button click listeners
        addGoalButton.setOnClickListener(v -> {
            if (!weightEditText.getText().toString().isEmpty()) {
                goalWeight = Float.parseFloat(weightEditText.getText().toString());
                goalWeightText = "Goal Weight: " + goalWeight + " lbs";
                displayGoalWeight();
            } else {
                Toast.makeText(this, "Please enter a goal weight.", Toast.LENGTH_SHORT).show();
            }
        });

        logWeightButton.setOnClickListener(v -> {
            String timestamp = String.valueOf(System.currentTimeMillis()); // Get current timestamp

            // Check if the weight input is not empty
            if (!weightEditText.getText().toString().isEmpty()) {
                float weight = Float.parseFloat(weightEditText.getText().toString());

                // Log the weight
                if (userDatabase.logWeight(getIntent().getIntExtra("userId", -1), weight, timestamp)) {
                    displayWeights(username);
                } else {
                    Toast.makeText(this, "Failed to log weight.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a weight.", Toast.LENGTH_SHORT).show();
            }
        });

        // Display weights on create
        displayWeights(username);

        // Set up click listener for edit rows button
        editRowsButton.setOnClickListener(v -> {
            if (weightEntries.size() > 0) {
                boolean deleted = userDatabase.deleteLatestWeight(getIntent().getIntExtra("userId", -1));
                if (deleted) {
                    Toast.makeText(this, "Latest weight entry deleted.", Toast.LENGTH_SHORT).show();
                    displayWeights(username); // Refresh the list after deletion
                } else {
                    Toast.makeText(this, "Failed to delete latest weight.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "No weight entries to delete.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayGoalWeight() {
        TextView goalWeightTextView = findViewById(R.id.goal_weight_text);
        goalWeightTextView.setText(goalWeightText);
    }

    private void displayWeights(String username) {
        Cursor cursor = userDatabase.getUserWeights(username);
        weightEntries.clear(); // Clear existing entries

        if (cursor != null) {
            // Print column names for debugging
            for (int i = 0; i < cursor.getColumnCount(); i++) {
                Log.d("WeightDisplay", "Column name: " + cursor.getColumnName(i));
            }

            // Move to the first row and read the data
            if (cursor.moveToFirst()) {
                do {
                    int weightColumnIndex = cursor.getColumnIndex("weight"); // Check column index
                    int timestampColumnIndex = cursor.getColumnIndex("timestamp"); // Check column index

                    if (weightColumnIndex != -1 && timestampColumnIndex != -1) {
                        float weight = cursor.getFloat(weightColumnIndex);
                        String timestamp = cursor.getString(timestampColumnIndex);
                        weightEntries.add(new WeightEntry(weight, timestamp));
                    } else {
                        Log.e("WeightDisplay", "Column indices are invalid: weightColumnIndex=" + weightColumnIndex + ", timestampColumnIndex=" + timestampColumnIndex);
                    }
                } while (cursor.moveToNext());
                cursor.close(); // Close the cursor
            }
        } else {
            Log.e("WeightDisplay", "Cursor is null");
        }

        adapter = new WeightAdapter(weightEntries, this); // Create and set adapter
        recyclerView.setAdapter(adapter);
    }

}

