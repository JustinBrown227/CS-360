package com.example.weighttracker_justinbrown;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 2; // Incremented for new table

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE users (ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");

        // Create weights table
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, weight REAL, timestamp TEXT, " +
                "FOREIGN KEY(user_id) REFERENCES users(ID))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");
        onCreate(db);
    }

    // Method to check if a user exists
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean exists = cursor.getCount() > 0; // Returns true if user exists
        cursor.close();
        return exists;
    }

    // Method to get user ID by username
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT ID FROM users WHERE username = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});

        int userId = -1; // Default value if not found

        // Ensure the cursor is not null and move to the first record
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                // Get the index of the ID column
                int idColumnIndex = cursor.getColumnIndex("ID");
                if (idColumnIndex != -1) { // Check if the column index is valid
                    userId = cursor.getInt(idColumnIndex); // Get user ID
                }
            }
            cursor.close(); // Always close the cursor to avoid memory leaks
        }

        return userId; // Return -1 if not found
    }

    // Method to check if a username exists
    public boolean usernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username});
        boolean exists = cursor.getCount() > 0; // Returns true if username exists
        cursor.close();
        return exists;
    }

    // Method to add a user
    public boolean addUser(String username, String password) {
        if (usernameExists(username)) {
            return false; // Username already exists
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);

        long result = db.insert("users", null, contentValues);
        return result != -1; // Returns true if the insert was successful
    }

    // Log weight method
    public boolean logWeight(int userId, float weight, String timestamp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("weight", weight);
        values.put("timestamp", timestamp);

        long result = db.insert("weights", null, values);
        return result != -1; // Return true if insertion is successful
    }

    public boolean deleteLatestWeight(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete the latest weight by timestamp
        return db.delete("weights",
                "id = (SELECT id FROM weights WHERE user_id = ? ORDER BY timestamp DESC LIMIT 1)",
                new String[]{String.valueOf(userId)}) > 0;
    }

    // Method to get user weights
    public Cursor getUserWeights(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT weights.weight, weights.timestamp " +
                        "FROM weights " +
                        "INNER JOIN users ON weights.user_id = users.ID " +
                        "WHERE users.username = ? " +
                        "ORDER BY weights.timestamp DESC",
                new String[]{username}
        );
    }

}