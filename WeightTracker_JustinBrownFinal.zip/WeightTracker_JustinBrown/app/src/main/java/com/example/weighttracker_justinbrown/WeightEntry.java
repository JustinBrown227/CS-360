package com.example.weighttracker_justinbrown;
//WeightEntry.java

import java.text.SimpleDateFormat;
import java.util.Date;

public class WeightEntry {
    private float weight;
    private String timestamp;

    public WeightEntry(float weight, String timestamp) {
        this.weight = weight;
        this.timestamp = formatTimestamp(timestamp); // Format the timestamp
    }

    private String formatTimestamp(String timestamp) {
        long timeInMillis = Long.parseLong(timestamp);
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss"); // Desired date format
        return sdf.format(new Date(timeInMillis));
    }

    public float getWeight() {
        return weight;
    }

    public String getTimestamp() {
        return timestamp;
    }
    public String getFormattedWeight() {
        return weight + " lbs";
    }
}
